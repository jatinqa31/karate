The Repo is base setup for the integration between Karate and Extent report.
The Libraries are used in this are :

            karate-core       :1.2.0
            karate-junit5     : 1.2.0
            extentreports     :5.0.9
           cucumber-reporting :5.6.0
	

          
Previously Karete using the ExecutionHook now it is replaced by the RunTimeHook.

